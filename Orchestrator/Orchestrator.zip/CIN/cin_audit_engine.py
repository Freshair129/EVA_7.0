# ============================================================
# CIN AUDIT ENGINE — EVA 5.5-AI (UPDATED WITH PERSONA LOCK SUPPORT)
# ============================================================

import json
import os
import time
import copy

class CINAuditEngine:

    def __init__(self, base_path, persona_lock_manager):
        self.base = base_path.rstrip("/")
        self.lock = persona_lock_manager

        self.log_path = f"{self.base}/logs/cin_audit/"
        os.makedirs(self.log_path, exist_ok=True)

        self.max_bytes = 4096

        # forbidden content markers
        self.forbidden_patterns = [
            "raw_memory",
            "full_episodic",
            "\"memory\": {",
            "semantic_memory_entry"
        ]

        self.required_directive_keywords = [
            "SYSTEM:",
            "Memory is immutable",
            "Use persona_brief",
            "Do not modify memory"
        ]

    # ----------------------------------------------------------
    def write_log(self, turn_id, report):
        fpath = os.path.join(self.log_path, f"CIN_AUDIT_{turn_id}.json")
        with open(fpath, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        return fpath

    def context_bytes(self, ctx):
        return len(json.dumps(ctx, ensure_ascii=False).encode("utf-8"))

    # ----------------------------------------------------------
    # MAIN AUDIT METHOD
    # ----------------------------------------------------------
    def audit(
        self,
        llm_context_block,
        injection_metadata,
        persona_state_core,
        persona_state_runtime,
        emotional_state,
        episode_count,
        boot_meta
    ):

        turn_id = injection_metadata.get("turn_id", f"AUD-{int(time.time())}")
        timestamp = injection_metadata.get("timestamp", time.time())

        ctx = copy.deepcopy(llm_context_block)

        audit_status = "pass"
        warnings = []
        fatal = []
        fixes = []

        # ======================================================
        # 1) PERSONA CONSISTENCY RULE FOR LOCK MODE
        # ======================================================
        result = self.lock.validate_persona(
            ctx.get("persona_brief", {}),
            episode_count
        )

        if result["status"] == "fail":
            fatal.append({
                "persona_lock_violation": result["inconsistent_fields"]
            })
            audit_status = "fail"

        elif result["status"] == "warn":
            warnings.append({
                "persona_drift_warning": result["inconsistent_fields"]
            })

        # ======================================================
        # 2) Emotional mismatch → auto-correct
        # ======================================================
        emo_now = ctx.get("emotional_brief", {})
        emo_fixed = False
        inconsistent_emotions = []

        for k, v in emotional_state.items():
            if k not in emo_now:
                inconsistent_emotions.append(k)
                emo_fixed = True
            else:
                if abs(emo_now[k] - v) > 0.05:
                    inconsistent_emotions.append(k)
                    emo_fixed = True

        if emo_fixed:
            ctx["emotional_brief"] = emotional_state.copy()
            warnings.append({"emotional_auto_correct": inconsistent_emotions})
            fixes.append("emotion_corrected")

        # ======================================================
        # 3) Directive Integrity
        # ======================================================
        directives = ctx.get("llm_directives", "")
        missing = [k for k in self.required_directive_keywords if k not in directives]

        if missing:
            warnings.append({"directive_missing": missing})
            fixes.append("regenerate_directives")

            ctx["llm_directives"] = (
                "SYSTEM: EVA CIN v5.5\n"
                "Memory is immutable.\n"
                "Use persona_brief and emotional_brief.\n"
                "Do not modify memory.\n"
            )

        # ======================================================
        # 4) Memory Leak Inspection
        # ======================================================
        ctx_str = json.dumps(ctx, ensure_ascii=False)
        leaks = [p for p in self.forbidden_patterns if p in ctx_str]

        if leaks:
            fatal.append({"memory_leak": leaks})
            audit_status = "fail"

        # ======================================================
        # 5) Context Size Overflow
        # ======================================================
        size_before = self.context_bytes(ctx)
        size_after = size_before

        if size_before > self.max_bytes:
            ctx["completed_topics"] = []
            fixes.append("truncate_completed_topics")
            size_after = self.context_bytes(ctx)

        # ======================================================
        # 6) Low-Uptime Warning
        # ======================================================
        if boot_meta.get("uptime", 999) < 1.0:
            warnings.append("low_uptime_reduce_context")
            ctx["high_salience_episode_refs"] = []
            fixes.append("reduce_context_mode")

        # ======================================================
        # Create report
        # ======================================================
        report = {
            "turn_id": turn_id,
            "timestamp": timestamp,
            "audit_status": audit_status,
            "episode_count": episode_count,
            "warnings": warnings,
            "fatal_errors": fatal,
            "fixes_applied": fixes,
            "size_before": size_before,
            "size_after": size_after,
        }

        log_path = self.write_log(turn_id, report)

        if audit_status == "fail":
            return {
                "audit_status": "fail",
                "validated_context_block": None,
                "audit_report": report,
                "log_path": log_path
            }

        return {
            "audit_status": audit_status,
            "validated_context_block": ctx,
            "audit_report": report,
            "log_path": log_path
        }
