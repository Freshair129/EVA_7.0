# ============================================================
# CIN FORMATTING LAYER — EVA 5.5-AI
# With Formatting Rules Enforcement
# ============================================================

import json


class CINFormattingLayer:

    def __init__(self, max_bytes=4096):
        self.max_bytes = max_bytes

    # ----------------------------------------------------------
    # Byte Clamp
    # ----------------------------------------------------------
    def clamp_size(self, text):
        data = text.encode("utf-8")
        if len(data) <= self.max_bytes:
            return text
        return data[:self.max_bytes].decode("utf-8", errors="ignore")

    # ----------------------------------------------------------
    # Converts dict/list → human readable formatted block
    # With indentation + bullet formatting
    # ----------------------------------------------------------
    def format_block(self, content, level=0):
        """
        Formatting rules applied:
        - lists → bullet points
        - nested lists/dicts → indented bullets
        - avoid long unreadable JSON chunks
        """
        indent = "  " * level
        bullet = indent + "- "

        # list → bullet list
        if isinstance(content, list):
            if len(content) == 0:
                return indent + "(empty)\n"
            text = ""
            for item in content:
                if isinstance(item, (dict, list)):
                    text += bullet + "\n" + self.format_block(item, level + 1)
                else:
                    text += bullet + str(item) + "\n"
            return text

        # dict → key: value with newline per item
        elif isinstance(content, dict):
            if len(content) == 0:
                return indent + "(empty)\n"
            text = ""
            for k, v in content.items():
                key_line = f"{indent}- **{k}**: "
                if isinstance(v, (dict, list)):
                    text += key_line + "\n" + self.format_block(v, level + 1)
                else:
                    text += key_line + str(v) + "\n"
            return text

        # primitive → simple text
        else:
            return indent + str(content) + "\n"

    # ----------------------------------------------------------
    # Format Section with Title
    # ----------------------------------------------------------
    def format_section(self, title, content):
        """
        Enforce formatting rules:
        - paragraph separation
        - newlines for new ideas
        """
        if content in (None, {}, [], ""):
            return ""

        formatted_body = self.format_block(content)
        return f"{title}\n{formatted_body}\n"

    # ----------------------------------------------------------
    # MAIN FORMATTER
    # ----------------------------------------------------------
    def format(self, ctx):
        """
        Core formatting rules applied:
        - Paragraph style
        - Bullet points for lists
        - Separate ideas per line
        - Important keys in **bold**
        """

        text = "[EVA CONTEXT v5.5]\n---\n\n"

        # Persona State
        text += self.format_section("## Persona State", ctx.get("persona_brief"))

        # Emotional State (9D)
        text += self.format_section("## Emotional State (9D)", ctx.get("emotional_brief"))

        # Session Summary
        text += self.format_section("## Session Summary", ctx.get("session_brief"))

        # Topics
        topics = {
            "active_topics": ctx.get("active_topics", []),
            "completed_topics": ctx.get("completed_topics", [])
        }
        text += self.format_section("## Conversation Topics", topics)

        # Semantic Use
        text += self.format_section("## User Semantic Profile (Top 5)", ctx.get("top_semantic_use"))

        # Important Episodes
        text += self.format_section("## Important Recent Episodes", ctx.get("high_salience_episode_refs"))

        # Directives
        text += self.format_section("## EVA Directives", ctx.get("llm_directives"))

        # clamp to safe size
        return self.clamp_size(text)
